/*
    This is Asm1, created by Kieu Kim Duc
    Name of project: Decipher Triangle
    Date of creation: 1/1/2022
    Date of modified: 4/1/2022

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
#define PI 3.14159
float A[2]; // tọa độ điểm A
float B[2]; // tọa độ điểm B
float C[2]; // tọa độ điểm C
float canh_goc[6];// mảng cạnh góc tam giác ABC
float dc[3]; // màng đường cao
float Stg[1]; // mảng diện tích tam giác
float trungtuyen[3]; //mảng đường trung tuyến
float trongtam[2]; //mảng tọa độ trọng tâm tam giác


//hàm nhập tọa độ các đỉnh
void nhap_toa_do();

//hàm lưu cạnh góc vào mảng
void goccanh_tamgiac();

// hàm ktra 3 cạnh có tạo thành tam giác
bool kiemtra_tamgiac();

// xét xem tam giác gì?
void xet_tamgiac();

// hàm tính diện tích tam giác ABC
void dientich_tamgiac();

//hàm tính đường cao tam giác ABC
void  duongcao_tamgiac();

//hàm tính độ dài đường trung tuyến
void trungtuyen_tamgiac();

//hàm tìm tọa độ trọng tâm tam giác
void tam_tamgiac();

void giaima_tamgiac();

int main()
{
    nhap_toa_do();
    giaima_tamgiac();
    return 0;
}

void nhap_toa_do()
{
    printf("Nhap toa do diem A\n");
    printf("Ax= ");
    scanf("%f", &A[0]);
    printf("Ay= ");
    scanf("%f", &A[1]);

    printf("\nNhap toa do diem B\n");
    printf("Bx= ");
    scanf("%f", &B[0]);
    printf("By= ");
    scanf("%f", &B[1]);

    printf("\nNhap toa do diem C\n");
    printf("Cx= ");
    scanf("%f", &C[0]);
    printf("Cy= ");
    scanf("%f", &C[1]);

    printf("Toa do diem A da nhap: A(%0.2f, %0.2f)\n", A[0], A[1]);
    printf("Toa do diem B da nhap: B(%0.2f, %0.2f)\n", B[0], B[1]);
    printf("Toa do diem C da nhap: C(%0.2f, %0.2f)\n", C[0], C[1]);




}

void goccanh_tamgiac()
{
    //Tính cạnh tam giác ABC
    canh_goc[0]=sqrt((A[0]-B[0])*(A[0]-B[0])+(A[1]-B[1])*(A[1]-B[1]));// Độ dài AB
    canh_goc[1]=sqrt((A[0]-C[0])*(A[0]-C[0])+(A[1]-C[1])*(A[1]-C[1]));// Độ dài AC
    canh_goc[2]=sqrt((B[0]-C[0])*(B[0]-C[0])+(B[1]-C[1])*(B[1]-C[1]));// Độ dài BC

    //Tính góc tam giác ABC
    float CosA=(canh_goc[0]*canh_goc[0]+canh_goc[1]*canh_goc[1]-canh_goc[2]*canh_goc[2])/(2*canh_goc[0]*canh_goc[1]);
    float CosB=(canh_goc[0]*canh_goc[0]+canh_goc[2]*canh_goc[2]-canh_goc[1]*canh_goc[1])/(2*canh_goc[0]*canh_goc[2]);
    float CosC=(canh_goc[2]*canh_goc[2]+canh_goc[1]*canh_goc[1]-canh_goc[0]*canh_goc[0])/(2*canh_goc[2]*canh_goc[1]);

    canh_goc[3]= (acos(CosA) / PI ) * 180;// góc A
    canh_goc[4]= (acos(CosB) / PI ) * 180;// góc B
    canh_goc[5]= (acos(CosC) / PI ) * 180;// góc C

    printf("1. So do co ban cua tam giac:\n\n");
    printf("Chieu dai canh AB: %0.2f\n", canh_goc[0]);
    printf("Chieu dai canh AC: %0.2f\n", canh_goc[1]);
    printf("Chieu dai canh BC: %0.2f\n", canh_goc[2]);
    printf("Goc A: %0.2f\n", canh_goc[3]);
    printf("Goc B: %0.2f\n", canh_goc[4]);
    printf("Goc C: %0.2f\n", canh_goc[5]);
}

bool kiemtra_tamgiac()
{

    float xAB=B[0]-A[0];
    float yAB=B[1]-A[1];
    float xAC=C[0]-A[0];
    float yAC=C[1]-A[1];
    if(xAC==0&&xAB==0||yAC==0&&yAB==0)
    {
        return false;

    }else if(xAB/xAC!=yAB/yAC)
    {
        return true;

    }else
    {
        return false;
    }
}

void xet_tamgiac()
{
    float AB=canh_goc[0];
    float AC=canh_goc[1];
    float BC=canh_goc[2];
    // xét tam giác vuông or vuông cân
    if((int)canh_goc[3]==90)
    {
        if(AB==AC){
            printf("==> Tam giac ABC la tam giac vuong can tai A\n\n");
        }else
        {
             printf("==> Tam giac ABC la tam giac vuong tai A\n\n");
        }
    }
    else if((int)canh_goc[4]==90)
    {
        if(AB==BC){
            printf("==> Tam giac ABC la tam giac vuong can tai B\n\n");
        }else
        {
             printf("==> Tam giac ABC la tam giac vuong tai B\n\n");
        }
    }
    else if((int)canh_goc[5]==90)
    {
        if(BC==AC){
            printf("==> Tam giac ABC la tam giac vuong can tai C\n\n");
        }else
        {
             printf("==> Tam giac ABC la tam giac vuong tai C\n\n");
        }
    }
    //Xét tam giác cân
    else if(AB==AC)
    {
        printf("==> Tam giac ABC la tam giac can tai A\n\n");
    }
    else if(AB==BC)
    {
        printf("==> Tam giac ABC la tam giac can tai B\n\n");
    }
    else if(BC==AC)
    {
        printf("==> Tam giac ABC la tam giac can tai C\n\n");
    }
    //Xét tam giác đều
    else if(AB==AC&&AC==BC)
    {
        printf("==> Tam giac ABC la tam giac deu\n\n");
    }
    //Xét tam giác nhọn
    else if(canh_goc[3]<90&&canh_goc[4]<90&&canh_goc[5]<90)
    {
        printf("==> Tam giac ABC la tam giac nhon\n\n");
    }
    //Xét tam giác tù
    else if(canh_goc[3]>90||canh_goc[4]>90||canh_goc[5]>90)
    {
        printf("==> Tam giac ABC la tam giac tu");
        if(canh_goc[3]>90)
        {
            printf(" tai A\n\n");
        }
        if(canh_goc[4]>90)
        {
            printf(" tai B\n\n");
        }
        if(canh_goc[5]>90)
        {
            printf(" tai C\n\n");
        }
    }
    //Tam giác thường
    else
    {
        printf("==> Tam giac ABC la tam giac thuong\n\n");
    }
}

void dientich_tamgiac()
{
    float  p=0.5*(canh_goc[0]+canh_goc[1]+canh_goc[2]); // p là nửa chu vi tam giác
    Stg[0]=sqrt(p*(p-canh_goc[0])*(p-canh_goc[1])*(p-canh_goc[2])); //công thức heron
    printf("2. ==> Dien tich tam giac ABC la: %0.2f\n\n", Stg[0]);
}

 void duongcao_tamgiac()
{
    dc[0]=(2*Stg[0])/(canh_goc[2]); // đường cao từ đỉnh A
    dc[1]=(2*Stg[0])/(canh_goc[1]); // đường cao từ đỉnh B
    dc[2]=(2*Stg[0])/(canh_goc[0]); // đường cao từ đỉnh C

    printf("3. So do nang cao cua tam giac ABC:\n\n");
    printf("Do dai duong cao tu dinh A: %0.2f\n", dc[0]);
    printf("Do dai duong cao tu dinh B: %0.2f\n", dc[1]);
    printf("Do dai duong cao tu dinh C: %0.2f\n", dc[2]);
}

void trungtuyen_tamgiac()
{
    trungtuyen[0]=sqrt(((canh_goc[1]*canh_goc[1])+(canh_goc[0]*canh_goc[0]))/2-((canh_goc[2]*canh_goc[2])/4)); //trung tuyến tại đỉnh A
    trungtuyen[1]=sqrt(((canh_goc[2]*canh_goc[2])+(canh_goc[0]*canh_goc[0]))/2-((canh_goc[1]*canh_goc[1])/4)); //trung tuyến tại đỉnh B
    trungtuyen[2]=sqrt(((canh_goc[1]*canh_goc[1])+(canh_goc[2]*canh_goc[2]))/2-((canh_goc[0]*canh_goc[0])/4)); //trung tuyến tại đỉnh C

    printf("Do dai duong trung tuyen tu dinh A: %0.2f\n", trungtuyen[0]);
    printf("Do dai duong trung tuyen tu dinh B: %0.2f\n", trungtuyen[1]);
    printf("Do dai duong trung tuyen tu dinh C: %0.2f\n\n", trungtuyen[2]);

}

void tam_tamgiac()
{
    trongtam[0]=(A[0]+B[0]+C[0])/3; // xG
    trongtam[1]=(A[1]+B[1]+C[1])/3; // yG
    printf("4. Toa do diem dac biet cua tam giac ABC:\n");
    printf("Toa do trong tam: [%0.2f; %0.2f]\n", trongtam[0], trongtam[1]);
}

void giaima_tamgiac()
{
    // vòng lặp ktra xem 3 điểm có hợp thành tam giác?
    while(kiemtra_tamgiac()==false)
    {
        system("clear");
        printf("A, B, C khong hop thanh mot tam giac\n\n");
        nhap_toa_do();
    }
    printf("A, B, C hop thanh mot tam giac\n\n");
    goccanh_tamgiac();
    xet_tamgiac();
    dientich_tamgiac();
    duongcao_tamgiac();
    trungtuyen_tamgiac();
    tam_tamgiac();
    printf("\n\t\tEND\n\n");


}
